# WC-10 Non-Home Impact Audit

## Mostly generic areas

- record storage uses `vehicleId`
- Data CSV vehicle options are generated dynamically
- backup metadata counts vehicles dynamically
- vehicle summary reports iterate vehicles

## Required changes

### Settings

The current one-button `Swap Vehicle Circles` control is a confirmed two-item implementation and must be replaced.

### Restore

Vehicle object merge is index based and must change to ID based.

### Data import

The selector must not allow an unconfigured blank vehicle to receive operational records unless explicitly intended after setup.

### Reports

Blank/unconfigured vehicles must not be shown as ordinary configured vehicles or produce fabricated totals.

### Backup schema

Packaged documentation currently shows a two-vehicle example and slot 0/1. It must be revised for the new schema and order list.

### Diagnostics

WC-10 diagnostics must report:

- ordered vehicle IDs
- configured/unconfigured state
- position mapping
- per-vehicle record counts
- migration version
