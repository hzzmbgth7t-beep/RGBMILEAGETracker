# WC-10 Orientation and Layout Impact

## Confirmed conflict

The baseline intentionally enforces portrait in two places:

1. manifest orientation
2. runtime Screen Orientation API request

Both conflict with the approved landscape requirement.

## Required controlled change

- revise manifest orientation
- remove the runtime portrait lock
- verify portrait and landscape independently
- record first launch, relaunch, and rotation behavior
- do not treat Safari as standalone acceptance

## CSS condition

The baseline contains accumulated Home and dock overrides. WC-10 must not add another final override block.

Before three-vehicle geometry:

1. inventory governing selectors
2. identify the final computed contract
3. remove superseded Home-only definitions in the WC-10 working copy
4. define one portrait layout contract
5. define one landscape layout contract
6. connect runtime diameter variables
7. preserve unrelated screen styles

## Geometry gate

Portrait and landscape geometry work starts only after the three-vehicle data/order model passes.
