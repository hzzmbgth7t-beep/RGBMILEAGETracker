# RGBM WC-10 Baseline Provenance and Impact Audit

**Version:** 1.0  
**Date:** 2026-07-25  
**Status:** COMPLETE — NO APPLICATION CODE MODIFIED  
**Locked baseline:** `v2.1.6l`  
**Target implementation working copy:** `v2.1.6l-wc10`

## Purpose

Prove the WC-10 source baseline and identify every known two-vehicle, position, migration, orientation, layout, restore, and documentation assumption that must be addressed before implementation.

## Result

The locked baseline is intact and usable as the functional source.

WC-10 implementation is not a one-line third-slot change. The audit found blocking assumptions in:

- state initialization
- normalization and restore
- acquisition migration
- position/identity coupling
- vehicle saving
- backup merge behavior
- two-item reordering
- blank-vehicle behavior
- portrait orientation locks
- Home layout CSS
- historical governing documentation

The baseline also contains useful generic vehicle-ID-based behavior that can be preserved.
