# WC-10 Data Migration and Restore Impact

## Current mechanism

- Storage key: `RGBM_DATA_v213d`
- `loadData()` reads the active key, then legacy keys.
- `normalizeData()` acts as both normalizer and de facto migration layer.
- `SCHEMA_VERSION` equals the application version.
- There is no explicit migration registry.
- Restore also calls `normalizeData()`.
- Vehicle merge is index based.

## Required WC-10 design

### Schema

Introduce an explicit schema/migration identifier separate from display version.

### Vehicle identity

- Preserve every existing `vehicleId`.
- Add a unique ID for the new blank vehicle.
- Do not infer identity from array position or `slot`.

### Order

Add a separate persisted ordered-ID list:

```text
vehicleOrder: [idA, idB, idC]
```

### Blank record

Create one record with:

```text
setupComplete: false
title/image/history fields empty
```

The exact stored field names must match the verified implementation design.

### Migration sequence

1. Clone or preserve original data before mutation.
2. Normalize existing vehicles without truncation.
3. verify and stabilize IDs
4. derive existing display order
5. append one blank vehicle only when required
6. create the three-ID order list
7. validate every record's `vehicleId`
8. record migration version
9. save only after validation succeeds

### Restore

- normalize all incoming vehicle records
- merge vehicles by `vehicleId`
- merge operational records by record ID and vehicle ID
- restore order separately
- never merge vehicle fields by array index
- support legacy two-vehicle backups
- round-trip three-vehicle backups without loss

## Required evidence

- before/after IDs
- counts by vehicle ID
- association hashes or equivalent deterministic comparison
- repeated-migration result
- reordered-backup merge result
- legacy backup restore
- three-vehicle backup round trip
