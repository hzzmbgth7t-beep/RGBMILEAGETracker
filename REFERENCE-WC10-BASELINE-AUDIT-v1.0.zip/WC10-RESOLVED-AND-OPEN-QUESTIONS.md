# WC-10 Resolved and Open Questions

## Resolved by baseline inspection

- Active storage key: `RGBM_DATA_v213d`
- Current migration hook: `normalizeData()` through `loadData()` and restore
- Current order mechanism: vehicle array order plus mutable `slot`
- Current reorder UI: one two-item swap
- Current image storage: data URL in `primaryPhoto`
- Current image processing: FileReader, canvas resize, JPEG data URL
- Current delete behavior: archive exists; no governed hard delete workflow found
- Current import merge: vehicle objects merge by array index
- Current landscape policy: portrait locked in manifest and runtime

## Still open before affected implementation

- final explicit schema-version value and migration-version field
- exact blank-record field names
- exact large-to-lower portrait diameter ratio
- exact calibrated portrait and landscape spacing constants
- whether an unconfigured blank record appears in every non-Home selector
- whether resetting the new Jeep returns it to blank state or only archives it
- exact image-replacement cache/reference strategy

These items must be resolved in the WC-10 implementation design and may not be guessed during coding.
