# WC-10 Audit Document Index

| Document | Purpose |
|---|---|
| README.md | Package purpose and result |
| BUILD-DOCUMENTATION-POLICY.md | Mandatory documentation rule |
| WC10-BASELINE-PROVENANCE-REPORT.md | Locked source proof |
| BASELINE-PROVENANCE.json | Machine-readable provenance |
| BASELINE-FILE-INVENTORY.csv | Full source inventory and hashes |
| CORE-FILE-HASHES.json | Core implementation hashes |
| WC10-TWO-VEHICLE-ASSUMPTION-AUDIT.md | Curated blocking findings |
| TWO-VEHICLE-ASSUMPTION-HITS.csv | Raw search evidence |
| WC10-CURATED-FINDING-REGISTER.csv | Structured confirmed findings |
| WC10-GENERIC-CAPABILITY-AUDIT.md | Reusable generic behavior |
| WC10-GENERIC-CAPABILITY-REGISTER.csv | Structured reusable behavior |
| KEY-SELECTOR-OCCURRENCES.csv | Home/dock selector counts |
| WC10-DATA-MIGRATION-AND-RESTORE-IMPACT.md | Migration and restore design impact |
| WC10-ORIENTATION-AND-LAYOUT-IMPACT.md | Landscape and CSS impact |
| WC10-NON-HOME-IMPACT-AUDIT.md | Reports/Data/Settings/import/export impact |
| WC10-RESOLVED-AND-OPEN-QUESTIONS.md | Baseline answers and remaining decisions |
| WC10-IMPLEMENTATION-GATE-PLAN.md | Ordered implementation gates |
| WC10-RISK-REGISTER.md | Risks and mitigations |
| WC10-AUDIT-TRACEABILITY-MATRIX.md | Specification-to-evidence mapping |
| CHANGELOG.md | Audit package changes |
| VERSION-HISTORY.md | Package lineage |
| GOVERNANCE-COMPLIANCE-CHECKLIST.md | Required documentation check |
| HANDOFF-AUTHORIZATION.md | Authorized next step |
| ARCHIVE-MANIFEST.json | File hashes and inventory |
| FULL-COMPLIANCE-AUDIT.txt | Artifact compliance result |
