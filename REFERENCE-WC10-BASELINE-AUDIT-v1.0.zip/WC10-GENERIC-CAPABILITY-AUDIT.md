# WC-10 Generic Capability Audit

These baseline behaviors are already vehicle-count tolerant and should be preserved where possible.

## G-01 — Home rendering iterates the vehicle array

`home()` uses:

```text
state.vehicles.map((v,i)=>circleHtml(v,i))
```

The rendering loop itself is not capped at two.

## G-02 — Circle rendering is index-generic

`circleHtml(v,i)` generates a complete circle/label unit for an arbitrary index.

It requires blank-state accessibility and setup-state changes, but not a complete rewrite.

## G-03 — Record ownership is generally vehicle-ID based

Fuel, maintenance, insurance, and acquisition records use `vehicleId`.

This is the main protection for preserving existing data during reorder.

## G-04 — Vehicle lookup is ID based

`getVehicle(id)` searches by `vehicleId`.

## G-05 — CSV vehicle selector is generated dynamically

The Data screen uses `state.vehicles.filter(Boolean).map(...)`.

It must exclude or label the unconfigured blank record appropriately, but it is not hard-coded to two options.

## G-06 — Backup metadata counts configured vehicles dynamically

The backup payload calculates vehicle count from the state.

## G-07 — Vehicle summary report iterates configured vehicles

The report uses `state.vehicles.filter(Boolean).map(...)`.

It needs blank-state handling but no two-item cap.

## G-08 — Existing empty-slot visual language is reusable

The current UI already uses a plus-style badge and `Add Vehicle` for a null slot. That visual concept can be retained while moving to an explicit blank record.

## Conclusion

WC-10 should refactor the blocking data/order boundaries while preserving the generic record, report, and renderer behavior.
