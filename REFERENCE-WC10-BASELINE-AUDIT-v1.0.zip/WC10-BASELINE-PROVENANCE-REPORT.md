# WC-10 Baseline Provenance Report

**Version:** 1.0  
**Date:** 2026-07-25

## Source

- Locked baseline: `v2.1.6l`
- Archive: `RGBM_v2.1.6l_2026-06-12_insurance_label_model_rollout.zip`
- Archive SHA-256: `74855830d31df5d37c00e14f53e259b5fb77d7953511a0bb0a4bf5950079dcb7`
- Archive integrity: PASS
- Source file count: 63
- Text files searched: 48

## Build identity found

- Application version: `2.1.6l`
- Build date: `2026-06-12`
- Storage key: `RGBM_DATA_v213d`
- Schema version implementation: tied directly to application version
- Service-worker cache: `rgbm-v2.1.6l-2026-06-12`
- Manifest start URL: `./index.html?v=216l`

## Source-control conclusion

- Fresh locked baseline is available.
- No failed working-copy code was used.
- No application code was modified during this audit.
- WC-10 may use this archive only after the implementation plan incorporates every blocking finding.
