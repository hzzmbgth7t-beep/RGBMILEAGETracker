# WC-10 Two-Vehicle Assumption Audit

**Version:** 1.0  
**Result language:** PASS, FAIL, N/A

## Executive result

**Implementation readiness: FAIL until the blocking findings below are designed and traced.**

The baseline is functionally usable, but it has explicit two-vehicle constraints and position/identity coupling.

## Blocking findings

### B-01 — Blank state creates exactly two slots

**Evidence:** `app.js`, line 187

```text
vehicles:[null,null]
```

**Impact:** A new installation can never expose a third position without changing the state initializer.

**Required action:** Create a governed three-vehicle initialization/migration model.

---

### B-02 — Normalization truncates restored data to two vehicles

**Evidence:** `app.js`, line 205

```text
arr(input.vehicles).slice(0,2)
```

**Impact:** A backup containing three vehicles would silently lose the third during normalization.

**Required action:** Remove the two-item truncation and validate the target schema explicitly.

---

### B-03 — Normalization forces a minimum of only two slots

**Evidence:** `app.js`, line 206

```text
while(d.vehicles.length<2)
```

**Impact:** The normalized state never creates the third required position.

**Required action:** Replace the two-slot rule with the approved three-vehicle migration contract.

---

### B-04 — Vehicle acquisition migration also truncates to two

**Evidence:** `app.js`, line 222

```text
arr(input.vehicles).slice(0,2)
```

**Impact:** Acquisition data for a third imported vehicle would not be migrated.

**Required action:** Generalize acquisition migration and test all three IDs.

---

### B-05 — Position and vehicle object remain coupled through `slot`

**Evidence:** `app.js`, lines 298, 640, and 642

The normalized vehicle stores a numeric `slot`; saving writes directly to:

```text
state.vehicles[slot]=v
```

**Impact:** Reordering and identity are not cleanly separated. With three vehicles, saving after reorder could overwrite the wrong array position unless the model is redesigned carefully.

**Required action:** Use stable vehicle IDs for identity and a separate ordered-ID list for presentation.

---

### B-06 — Restore merge combines vehicles by array index

**Evidence:** `app.js`, line 1544

```text
state.vehicles[i]={...state.vehicles[i],...v}
```

**Impact:** A reordered backup can merge one vehicle's fields into another vehicle's position.

**Required action:** Merge vehicles by `vehicleId`, then restore order separately.

---

### B-07 — Reordering supports only one two-item swap

**Evidence:** `app.js`, line 1548

```text
[state.vehicles[0],state.vehicles[1]]
```

**Impact:** It cannot express six possible three-vehicle orders and has no accessible non-drag alternative beyond swapping two items.

**Required action:** Replace with ordered-ID controls supporting all three positions.

---

### B-08 — Blank-record semantics conflict with the approved third vehicle

Current behavior treats only `null` as an add slot:

- `circleHtml()` shows `Add Vehicle` only when the value is falsy.
- `vehicleTap()` opens setup only when the value is falsy.
- A truthy record with empty title/image is labeled `Vehicle` and opens fuel entry.

**Evidence:** `app.js`, lines 331, 635, and 636.

**Impact:** The approved blank record with a unique ID and `setupComplete:false` would behave as a configured vehicle unless explicit blank-state logic is added.

**Required action:** Introduce a governed blank/setup state independent of nullness.

---

### B-09 — Landscape is blocked by two portrait locks

**Evidence:**

- `manifest.json`, line 25: `"orientation": "portrait"`
- `app.js`, line 1553: `screen.orientation.lock("portrait")`

**Impact:** The approved three-across landscape design cannot be accepted while these locks remain.

**Required action:** Remove or revise both orientation restrictions as one controlled change.

---

### B-10 — Home CSS is structurally designed around the old two-circle layout

The baseline uses a vertical `.vehicle-area`, fixed circle limits, and many later overrides.

Key occurrence counts:

- `.screen.home`: 5
- `.home`: 13
- `.vehicle-area`: 3
- `.circleBtn`: 6
- `.bottom-nav`: 15
- landscape media blocks: 2

**Impact:** Adding a third layout through another override would repeat the selector-stacking failure pattern.

**Required action:** Consolidate the governed Home selectors before implementing portrait and landscape geometry.

---

### B-11 — Historical documentation explicitly governs two vehicles

Evidence includes:

- `RGBM-Stabilization-Decisions.md`: `Maximum 2 Vehicles`
- `RGBM-Stabilization-Decisions.md`: `Swap Vehicles Retained`
- `DATA-MODEL-v2.1.0.md`: slot is `0 or 1 for current two-circle layout`

**Impact:** The implementation would conflict with packaged documentation unless those decisions are explicitly superseded.

**Required action:** WC-10 documentation must revise the active model and identify the three-vehicle specification as the superseding authority.

## False-positive review

The raw search found `parsed.length<2` in CSV parsing. That condition means “header plus at least one data row” and is **not** a two-vehicle limit. It is excluded from the blocking register.

This manual review is required because raw text-search counts alone are not trustworthy conclusions.
