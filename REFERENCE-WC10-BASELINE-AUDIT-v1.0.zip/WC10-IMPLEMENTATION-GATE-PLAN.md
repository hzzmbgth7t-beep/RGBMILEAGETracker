# WC-10 Implementation Gate Plan

## Gate 1 — Provenance and impact audit

**Status:** COMPLETE

## Gate 2 — Data/order design

Required before code changes:

- explicit schema and migration version
- stable ID model
- separate `vehicleOrder`
- blank-record semantics
- ID-based restore merge
- legacy backup rules
- failure rollback behavior

## Gate 3 — Data implementation and automated tests

Implement and prove migration before Home layout work.

## Gate 4 — Reorder and blank setup

Implement all six permutations, persistence, and non-drag controls.

## Gate 5 — Non-Home support

Update Settings, Reports, Data, import/export, backup/restore, and diagnostics.

## Gate 6 — Orientation

Remove both portrait locks and verify rotation behavior.

## Gate 7 — Home CSS consolidation

Remove superseded governed Home selector blocks before adding the three-vehicle layout.

## Gate 8 — Portrait and landscape geometry

Implement maximum-valid sizing after the model and orientation gates pass.

## Gate 9 — Accessibility, regression, device evidence, and governed handoff

No later gate may begin when an earlier mandatory gate fails.
