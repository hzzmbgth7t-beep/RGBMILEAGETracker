# WC-10 Audit Traceability Matrix

| Specification requirement | Baseline evidence | Audit result | Required WC-10 gate |
|---|---|---|---|
| Three vehicle slots | app.js 187, 205, 206 | FAIL | Data/order design |
| Preserve IDs | vehicleId-based records; slot writes | AT RISK | Migration tests |
| Blank third record | null-only add behavior | FAIL | Blank-state design |
| Reorder three vehicles | app.js 1548 | FAIL | Reorder implementation |
| Persistent order | array order + slot | AT RISK | Separate vehicleOrder |
| Portrait hierarchy | two-item vertical CSS | FAIL | Home consolidation/geometry |
| Landscape three across | portrait locks | FAIL | Orientation + geometry |
| Maximum shared diameter | fixed circle caps | FAIL | Runtime geometry |
| Non-Home support | mixed generic/index-based behavior | AT RISK | Non-Home gate |
| Legacy import/export | truncation + index merge | FAIL | Restore redesign |
| Accessibility reorder | swap only | FAIL | Non-drag controls |
| Complete documentation | audit package | PASS | Continue enforcement |
