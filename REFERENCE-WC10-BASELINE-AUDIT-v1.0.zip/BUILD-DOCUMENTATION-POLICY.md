# Build Documentation Policy

**Status:** MANDATORY

Every build and audit artifact must include its complete governed documentation.

The artifact fails and must be withheld when a required document is missing, empty, inconsistent with identity, missing from the archive, or omitted from the compliance audit.
