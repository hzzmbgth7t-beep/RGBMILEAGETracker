# WC-10 Risk Register

| ID | Risk | Severity | Required mitigation |
|---|---|---:|---|
| R-01 | Third vehicle lost during normalization | Critical | Remove two-item truncation; migration tests |
| R-02 | Existing vehicle fields merged into wrong vehicle | Critical | Merge by vehicleId |
| R-03 | Save after reorder overwrites wrong position | Critical | Separate order from identity |
| R-04 | Duplicate blank vehicle on repeated startup | High | Idempotent migration marker |
| R-05 | Blank vehicle opens fuel instead of setup | High | Explicit setupComplete behavior |
| R-06 | Landscape remains locked | High | Remove manifest and runtime locks |
| R-07 | New CSS stacks on duplicated overrides | High | Consolidate Home selectors first |
| R-08 | Legacy backup loses or misorders vehicles | Critical | Legacy restore matrix |
| R-09 | Blank vehicle receives imported records | High | Selector/setup-state rule |
| R-10 | Historical docs contradict WC-10 | Medium | Superseding documentation |
| R-11 | Image replacement displays stale content | Medium | Explicit reference/cache strategy |
| R-12 | Documentation omitted | High | Build-blocking compliance audit |
