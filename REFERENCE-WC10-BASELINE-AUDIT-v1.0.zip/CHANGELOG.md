# Changelog

## v1.0 — 2026-07-25

- Proved locked `v2.1.6l` baseline provenance.
- Audited 63 source files and searched 48 text files.
- Identified and curated 11 blocking three-vehicle impacts.
- Distinguished generic reusable behavior from two-vehicle constraints.
- Resolved baseline storage, migration-hook, ordering, image, restore, and orientation questions.
- Defined the gated WC-10 implementation sequence.
- No application code modified.
