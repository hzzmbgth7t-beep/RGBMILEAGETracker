# WC-10 Data-Layer Implementation Plan

**Target:** `v2.1.6l-wc10`  
**Scope:** Data/order migration and automated tests only

## Phase 1 — Fresh source and test harness

- Extract locked baseline.
- Verify core hashes against provenance audit.
- Create isolated migration module or clearly bounded functions.
- Create automated test runner using synthetic fixtures.

## Phase 2 — Canonical schema

- Add separate data schema and migration constants.
- Add `vehicleOrder`.
- Add explicit blank vehicle factory.
- Remove `slot` as canonical authority.

## Phase 3 — Pure migration

- Implement migration without storage or UI side effects.
- Pass all migration fixtures.
- Prove idempotency.
- Prove no input mutation.

## Phase 4 — Validation

- Implement root, vehicle, reference, blank, record, and order validation.
- Use cataloged error codes.
- Test every rejection path.

## Phase 5 — Transactional storage

- Add new active and pending keys.
- Preserve legacy key.
- Validate pending and promoted data.
- Implement recovery behavior.

## Phase 6 — Restore merge

- Replace index-based vehicle merge.
- Implement Replace, Update, and Skip vehicle rules.
- Restrict Duplicate to operational records.
- Separate incoming order adoption.

## Phase 7 — Application integration

- Replace blank-data and load/normalize hooks.
- Replace vehicle lookup/save/order operations with ID-based interfaces.
- Do not implement Home geometry yet.

## Phase 8 — Regression and governed handoff

- Run fixture matrix.
- Run legacy backup restore.
- Verify existing records.
- Package full documentation and evidence.
- Stop before Home layout when any data-layer test fails.
