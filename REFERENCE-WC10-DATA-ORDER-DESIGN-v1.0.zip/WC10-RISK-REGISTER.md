# WC-10 Data/Order Risk Register

| ID | Risk | Severity | Mitigation |
|---|---|---:|---|
| DR-01 | Existing records attach to wrong vehicle | Critical | ID-based ownership and pre/post reference audit |
| DR-02 | Save after reorder updates wrong object | Critical | Find/update by vehicleId |
| DR-03 | Third vehicle duplicated | High | Idempotent schema and migration checks |
| DR-04 | Legacy source destroyed | Critical | New key and retained legacy key |
| DR-05 | Restore merges by position | Critical | ID-based merge only |
| DR-06 | More than three vehicles silently lost | Critical | Reject; never truncate |
| DR-07 | Blank vehicle receives operational data | High | setupComplete validation and selector exclusion |
| DR-08 | Empty setup creates acquisition record | Medium | Meaningful-field check |
| DR-09 | Pending migration treated as active | High | Explicit pending promotion flow |
| DR-10 | Schema/app version remain coupled | Medium | Separate constants and tests |
| DR-11 | Documentation or fixtures omitted | High | Build-blocking artifact audit |
