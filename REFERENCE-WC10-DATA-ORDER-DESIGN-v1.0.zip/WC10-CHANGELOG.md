# WC-10 Data/Order Design Changelog

## v1.0 — 2026-07-25

- Locked schema 3.0.0 and migration identifier.
- Locked new active/pending storage keys and legacy-key retention.
- Defined stable vehicle identity and separate order.
- Defined explicit blank third-vehicle semantics.
- Defined idempotent migration and rejection behavior.
- Replaced index-based restore design with ID-based merge.
- Defined transaction, rollback, recovery, error codes, fixtures, and tests.
- No application code modified.
