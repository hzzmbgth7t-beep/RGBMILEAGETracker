# WC-10 Data/Order Design Handoff Authorization

**Status:** APPROVED

## Authorized next step

Implement the **WC-10 Data/Order Migration and Automated Test Harness** from a fresh `v2.1.6l` extraction.

The implementation is limited to:

- canonical schema
- migration
- validation
- transactional storage
- restore merge
- ID-based save/order helpers
- synthetic automated tests
- documentation and evidence

## Not authorized yet

- three-vehicle Home layout
- portrait/landscape circle geometry
- chrome changes
- production deployment
- promotion
- SP-01 or WC-09 modifications

The data-layer implementation must pass all mandatory tests before non-Home or Home UI work begins.
