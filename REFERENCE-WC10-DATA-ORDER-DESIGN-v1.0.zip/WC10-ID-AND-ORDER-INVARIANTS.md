# WC-10 ID and Order Invariants

**Version:** 1.0  
**Status:** APPROVED

## Identity invariants

- `vehicleId` never changes during reorder.
- Existing IDs survive migration and restore.
- Record ownership always uses `vehicleId`.
- Display position never acts as identity.

## Order invariants

- `vehicleOrder` contains exactly three IDs.
- The order list is the only canonical presentation order.
- The `vehicles` array may remain storage-stable; rendering resolves objects through `vehicleOrder`.
- Reorder operations are atomic list transformations.

## Portrait mapping

```text
vehicleOrder[0] -> large top
vehicleOrder[1] -> lower left
vehicleOrder[2] -> lower right
```

## Landscape mapping

```text
vehicleOrder[0] -> left
vehicleOrder[1] -> center
vehicleOrder[2] -> right
```

## Save invariants

Saving a vehicle:

- finds it by `vehicleId`
- updates that object
- never writes `state.vehicles[position]`
- does not modify order unless the user explicitly reorders

## Restore invariants

- vehicle definitions merge by ID
- order merges separately
- operational records retain their IDs and vehicle IDs
