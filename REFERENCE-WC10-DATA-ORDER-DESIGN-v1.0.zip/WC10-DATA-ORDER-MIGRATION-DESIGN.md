# WC-10 Data/Order Migration Design

**Version:** 1.0  
**Status:** APPROVED FOR IMPLEMENTATION

## 1. Canonical storage

### Active storage key

```text
RGBM_DATA_v3
```

### Legacy source key

```text
RGBM_DATA_v213d
```

The legacy key is retained as rollback evidence after successful migration. It is not deleted automatically.

### Schema identifiers

```json
{
  "schemaVersion": "3.0.0",
  "migrationVersion": "wc10-three-vehicle-v1"
}
```

The data schema version is independent from the visible application version.

## 2. Canonical root structure

```json
{
  "app": "RGB Mileage",
  "schemaVersion": "3.0.0",
  "appVersion": "2.1.6l-wc10",
  "migrationVersion": "wc10-three-vehicle-v1",
  "migrationHistory": [],
  "settings": {},
  "vehicleOrder": ["VEH-A", "VEH-B", "VEH-C"],
  "vehicles": [],
  "vehicleAcquisitionRecords": [],
  "fuelRecords": [],
  "maintenanceRecords": [],
  "insuranceRecords": [],
  "attachments": [],
  "createdAt": "",
  "modifiedAt": ""
}
```

## 3. Vehicle identity and position

- `vehicleId` is permanent identity.
- `vehicleOrder` is presentation order.
- Array position is not identity.
- Canonical vehicle objects do not use `slot`.
- Legacy `slot` may be read only while deriving initial order.
- Reordering changes only `vehicleOrder`.

## 4. Canonical vehicle record

```json
{
  "vehicleId": "VEH-...",
  "id": "VEH-...",
  "setupComplete": false,
  "status": "Active",
  "year": "",
  "make": "",
  "model": "",
  "nickname": "",
  "displayName": "",
  "badge": "",
  "primaryPhoto": "",
  "createdAt": "",
  "modifiedAt": ""
}
```

Additional verified legacy fields may be preserved, but no position field controls identity.

## 5. Blank vehicle semantics

An unconfigured vehicle:

- has a stable unique `vehicleId`
- has `setupComplete: false`
- has empty identity and image fields
- has no operational or acquisition records
- renders as plus symbol and `Add Vehicle`
- opens vehicle setup
- cannot receive fuel, maintenance, insurance, or CSV-import records

Saving valid vehicle identity sets `setupComplete: true`.

Image is optional. A valid identity requires at least one non-empty identifying text value from:

- nickname
- make
- model
- displayName

Year or badge alone is insufficient.

## 6. Exactly three positions

After successful migration:

- `vehicles.length === 3`
- `vehicleOrder.length === 3`
- all three vehicle IDs are unique
- the order list contains exactly the same IDs as the vehicle collection

For legacy source with more than three unique vehicles, migration aborts. No vehicle is silently truncated.

## 7. Existing vehicle preservation

Migration preserves:

- existing `vehicleId`
- record associations
- original visible order
- images
- status
- timestamps and supported metadata

If an existing configured vehicle lacks an ID, a new ID is assigned during the migration transaction and committed only after full validation.

## 8. Initial-order derivation

Order is derived in this sequence:

1. Use a valid existing `vehicleOrder`, when present.
2. Otherwise use unique valid legacy `slot` values.
3. Otherwise preserve source-array order.
4. Append any remaining vehicle IDs.
5. Create explicit blank records for missing legacy positions.
6. Append the new third blank vehicle when fewer than three records exist.

## 9. Acquisition records

Saving a blank vehicle setup must not fabricate an acquisition record.

Create an acquisition record only when at least one acquisition field is meaningful:

- acquisition date
- starting odometer
- purchase price
- seller

## 10. Selected vehicle

Any persisted selected vehicle remains tied to `vehicleId`.

If the selected ID is invalid after validation, clear the selection rather than remapping it by position.
