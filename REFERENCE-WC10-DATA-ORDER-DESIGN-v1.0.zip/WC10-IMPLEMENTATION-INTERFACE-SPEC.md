# WC-10 Data-Layer Implementation Interface

**Version:** 1.0  
**Status:** APPROVED

The implementation may use different internal names only when traceability documents the mapping.

## Required pure functions

```text
createBlankVehicle(now, idFactory) -> Vehicle
createBlankDataV3(now, idFactory) -> StateV3
normalizeLegacyVehicle(rawVehicle, context) -> Vehicle
deriveVehicleOrder(rawVehicles, normalizedVehicles, rawOrder) -> string[3]
migrateToV3(rawState, context) -> MigrationResult
validateStateV3(state) -> ValidationResult
mergeRestoreState(current, incoming, mode, options) -> MergeResult
```

Pure functions must not access `localStorage`, DOM, alerts, or navigation.

## Required state access functions

```text
getVehicleById(state, vehicleId) -> Vehicle | null
getOrderedVehicles(state) -> Vehicle[3]
updateVehicleById(state, vehicleId, patch) -> StateV3
setVehicleOrder(state, orderedIds) -> StateV3
moveVehicle(state, vehicleId, targetIndex) -> StateV3
```

## Required storage functions

```text
loadCanonicalState(storage) -> LoadResult
commitMigratedState(storage, state, report) -> CommitResult
recoverPendingMigration(storage) -> RecoveryResult
```

## Prohibited implementation patterns

```text
state.vehicles[position] = vehicle
vehicles.slice(0, 2)
while (vehicles.length < 2)
merge vehicle definitions by array index
derive record ownership from display position
silently truncate excess vehicles
```
