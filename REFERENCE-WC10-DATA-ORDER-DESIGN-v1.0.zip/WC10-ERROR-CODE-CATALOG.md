# WC-10 Migration Error Code Catalog

| Code | Meaning | Commit allowed |
|---|---|---|
| INVALID_SOURCE | Source is not a supported object | No |
| TOO_MANY_VEHICLES | More than three unique source vehicles | No |
| DUPLICATE_VEHICLE_ID | Vehicle IDs are duplicated ambiguously | No |
| ORPHAN_VEHICLE_REFERENCE | A record references an unknown vehicle | No |
| INVALID_VEHICLE_ORDER | Order is missing, duplicated, or references unknown IDs | No |
| INVALID_BLANK_VEHICLE | Unconfigured vehicle owns operational records | No |
| DUPLICATE_RECORD_ID | Record identity collision cannot be resolved under mode | No |
| CAPACITY_CONFLICT | Restore introduces unmatched configured vehicle with no blank position | No |
| SERIALIZATION_FAILED | Canonical state cannot be serialized | No |
| PENDING_WRITE_FAILED | Pending key cannot be written or read back | No |
| ACTIVE_WRITE_FAILED | Active key promotion failed | No |
| POST_WRITE_VALIDATION_FAILED | Stored active state differs or fails validation | No |
| STORAGE_QUOTA_EXCEEDED | Browser storage cannot hold safe transaction | No |
| RECOVERY_REQUIRED | Invalid active/pending combination needs user action | No |

Errors must identify the stage and code without including private vehicle content.
