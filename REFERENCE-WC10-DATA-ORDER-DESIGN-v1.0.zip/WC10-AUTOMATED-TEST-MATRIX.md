# WC-10 Automated Test Matrix

**Allowed results:** PASS, FAIL, N/A

## Migration

| ID | Test | Expected |
|---|---|---|
| MT-01 | Two configured legacy vehicles | Preserve both, append one blank |
| MT-02 | One configured and one null | Preserve configured, create two blanks |
| MT-03 | Two null legacy positions | Create three explicit blanks |
| MT-04 | Reversed legacy slots | Preserve visible order |
| MT-05 | Missing legacy slots | Preserve source-array order |
| MT-06 | Existing valid v3 state | No changes |
| MT-07 | Run migration twice | Byte-equivalent canonical data except allowed timestamps |
| MT-08 | Four unique source vehicles | Reject without commit |
| MT-09 | Duplicate vehicle IDs | Reject unless deterministic safe repair is defined |
| MT-10 | Orphan operational record | Reject without commit |
| MT-11 | Missing vehicle ID | Assign once and preserve after commit |
| MT-12 | Empty acquisition fields | Create no acquisition record |

## Reorder

| ID | Test | Expected |
|---|---|---|
| OT-01 | ABC to ACB | Only order list changes |
| OT-02 | ABC to BAC | Only order list changes |
| OT-03 | ABC to BCA | Only order list changes |
| OT-04 | ABC to CAB | Only order list changes |
| OT-05 | ABC to CBA | Only order list changes |
| OT-06 | Save vehicle after reorder | Correct ID updated |
| OT-07 | Restart and relaunch | Order persists |

## Restore

| ID | Test | Expected |
|---|---|---|
| RT-01 | Replace legacy two-vehicle backup | Migrate and append blank |
| RT-02 | Replace valid three-vehicle backup | Exact validated replacement |
| RT-03 | Update matching IDs | Merge by ID |
| RT-04 | Update unmatched vehicle with blank capacity | Consume blank position |
| RT-05 | Update unmatched vehicle without capacity | Explicit conflict |
| RT-06 | Incoming reordered backup | No accidental cross-vehicle merge |
| RT-07 | Duplicate record mode | Vehicle definitions not duplicated |
| RT-08 | Invalid incoming order | Reject order adoption |

## Transaction and recovery

| ID | Test | Expected |
|---|---|---|
| TX-01 | Validation failure | Legacy active state unchanged |
| TX-02 | Pending write failure | No active v3 key |
| TX-03 | Active promotion failure | Legacy key retained |
| TX-04 | Valid pending recovery | Controlled promotion |
| TX-05 | Invalid active v3 key | Recovery prompt and no silent fallback |
