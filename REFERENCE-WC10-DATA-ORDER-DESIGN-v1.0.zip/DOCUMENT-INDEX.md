# WC-10 Data/Order Migration Design Document Index

| Document | Purpose |
|---|---|
| README.md | Package identity and purpose |
| BUILD-DOCUMENTATION-POLICY.md | Mandatory documentation rule |
| SOURCE-REFERENCE.json | Locked source and audit provenance |
| WC10-DATA-ORDER-MIGRATION-DESIGN.md | Canonical storage, identity, order, and blank state |
| WC10-TARGET-DATA-SCHEMA.json | Machine-readable target schema |
| WC10-MIGRATION-CONTRACT.json | Machine-readable design contract |
| WC10-MIGRATION-ALGORITHM.md | Pure migration algorithm |
| WC10-VALIDATION-RULES.md | Canonical validation |
| WC10-BLANK-VEHICLE-STATE-MACHINE.md | Unconfigured/configured behavior |
| WC10-ID-AND-ORDER-INVARIANTS.md | Identity and display-order rules |
| WC10-RESTORE-MERGE-DESIGN.md | ID-based restore behavior |
| WC10-TRANSACTION-ROLLBACK-RECOVERY.md | Safe storage transaction and recovery |
| WC10-IMPLEMENTATION-INTERFACE-SPEC.md | Required function boundaries |
| WC10-ERROR-CODE-CATALOG.md | Controlled failure codes |
| WC10-ARCHITECTURE-DECISIONS.md | Locked ADRs |
| WC10-RISK-REGISTER.md | Risks and mitigations |
| WC10-TRACEABILITY-MATRIX.md | Requirement/design/test mapping |
| WC10-AUTOMATED-TEST-MATRIX.md | Mandatory tests |
| WC10-TEST-FIXTURE-CATALOG.md | Synthetic fixture inventory |
| fixtures/*.json | Synthetic input and expected-result fixtures |
| WC10-DATA-LAYER-IMPLEMENTATION-PLAN.md | Authorized implementation sequence |
| WC10-EVIDENCE-REPORT-TEMPLATE.md | Test evidence record |
| WC10-OPEN-DECISION-REGISTER.md | Locked and deferred decisions |
| WC10-CHANGELOG.md | Package changes |
| WC10-VERSION-HISTORY.md | Version lineage |
| WC10-HANDOFF-AUTHORIZATION.md | Authorized next step |
| GOVERNANCE-COMPLIANCE-CHECKLIST.md | Governance completion |
| ARCHIVE-MANIFEST.json | File inventory and hashes |
| FULL-COMPLIANCE-AUDIT.txt | Artifact compliance result |
