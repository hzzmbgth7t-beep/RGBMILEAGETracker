# RGBM WC-10 Data/Order Migration Design Package

**Version:** 1.0  
**Date:** 2026-07-25  
**Status:** COMPLETE — READY FOR DATA-LAYER IMPLEMENTATION  
**Locked baseline:** `v2.1.6l`  
**Target working copy:** `v2.1.6l-wc10`  
**Application code modified:** No

## Purpose

Define the exact data, identity, ordering, migration, restore, rollback, validation, and automated-test contract required before implementing the third vehicle.

## Governing decisions

- Vehicle identity is a stable `vehicleId`.
- Display position is stored separately in `vehicleOrder`.
- Canonical data contains exactly three vehicle records.
- Empty positions are explicit unconfigured vehicle records, not `null`.
- The third vehicle migration is idempotent.
- Restore merges vehicle definitions by `vehicleId`, never by array index.
- Operational records remain attached to stable vehicle IDs.
- No application UI or Home-layout code is authorized by this package.
