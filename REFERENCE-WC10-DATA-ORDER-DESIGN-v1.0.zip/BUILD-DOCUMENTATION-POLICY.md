# Build Documentation Policy

**Status:** MANDATORY

Every build, design package, audit, test harness, and install artifact must contain the complete documentation required by its governing specification.

The artifact fails and must be withheld when a mandatory document is missing, empty, inconsistent with identity, absent from the archive, or omitted from the compliance audit.
