# WC-10 Canonical Validation Rules

**Version:** 1.0  
**Status:** APPROVED

## Root validation

- `schemaVersion === "3.0.0"`
- `migrationVersion === "wc10-three-vehicle-v1"`
- `vehicles` is an array of exactly three objects
- `vehicleOrder` is an array of exactly three unique IDs
- the vehicle ID set equals the order ID set
- all required record arrays exist
- timestamps and settings are present

## Vehicle validation

For each vehicle:

- `vehicleId` is non-empty and unique
- `id === vehicleId`
- `setupComplete` is boolean
- canonical data has no authoritative `slot`
- unconfigured vehicles have empty identity/image fields
- configured vehicles have at least one approved identifying text value

## Reference validation

Every acquisition, fuel, maintenance, and insurance record:

- has a non-empty `vehicleId`
- references one of the three canonical vehicle IDs

Unknown references cause migration failure. They are not reassigned by position.

## Blank-vehicle validation

For every `setupComplete:false` vehicle:

- no acquisition record
- no fuel record
- no maintenance record
- no insurance record
- not eligible for CSV import
- visible state resolves to `Add Vehicle`

## Record validation

- required record IDs are unique within their collection
- duplicate IDs are handled only through an explicit restore mode
- records are never reassigned because order changed

## Order validation

- no duplicate IDs
- no unknown IDs
- no missing vehicle IDs
- reordering changes only `vehicleOrder`

## Commit validation

Validation runs:

1. after migration in memory
2. after serialization
3. after reading the pending key
4. after reading the promoted active key
