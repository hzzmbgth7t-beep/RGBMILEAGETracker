# WC-10 Data/Order Traceability Matrix

| Requirement | Design element | Fixture/test |
|---|---|---|
| Preserve existing IDs | Stable `vehicleId`; migration step 8 | MT-01, MT-04 |
| Add blank third vehicle | Explicit blank record; exactly three | MT-01, MT-02, MT-03 |
| No inherited data | Blank validation rules | MT-01, MT-12 |
| Idempotent migration | Schema/migration version checks | MT-06, MT-07 |
| Separate identity/order | `vehicleOrder`; no canonical slot | OT-01 through OT-07 |
| Save by ID | `updateVehicleById` | OT-06 |
| Restore by ID | Restore merge design | RT-01 through RT-08 |
| Preserve legacy backup | New active key and retained old key | TX-01 through TX-05 |
| No silent truncation | Reject >3 vehicles | MT-08 |
| Reject orphan records | Reference validation | MT-10 |
| Blank opens setup | State machine | UI integration test in later gate |
| No empty acquisition record | Meaningful-field rule | MT-12 |
| Complete documentation | Build policy and audit | Artifact audit |
