# WC-10 Data/Order Architecture Decisions

**Version:** 1.0

## ADR-D01 — Separate schema version from app version

**Status:** Accepted  
Canonical data uses schema `3.0.0` independently from visible app version.

## ADR-D02 — Use a new active storage key

**Status:** Accepted  
WC-10 writes `RGBM_DATA_v3` and retains `RGBM_DATA_v213d` for rollback.

## ADR-D03 — Store exactly three explicit vehicle records

**Status:** Accepted  
Canonical empty positions are unconfigured vehicle objects, not nulls.

## ADR-D04 — Use stable IDs and separate order

**Status:** Accepted  
`vehicleOrder` controls presentation. `vehicleId` controls ownership.

## ADR-D05 — Remove slot from canonical authority

**Status:** Accepted  
Legacy slot is read only for migration-order derivation.

## ADR-D06 — Reject silent truncation

**Status:** Accepted  
More than three source vehicles causes a controlled failure.

## ADR-D07 — Merge restore by ID

**Status:** Accepted  
Vehicle objects are never merged by array index.

## ADR-D08 — Preserve legacy source storage

**Status:** Accepted  
Successful migration does not automatically delete the legacy key.

## ADR-D09 — Do not fabricate acquisition records

**Status:** Accepted  
An acquisition record is created only when meaningful fields exist.

## ADR-D10 — Blank vehicles cannot receive operational records

**Status:** Accepted  
Setup must complete first.

## ADR-D11 — No destructive reset behavior in WC-10 data phase

**Status:** Accepted  
Archive may remain; reset-to-blank requires separate approval.
