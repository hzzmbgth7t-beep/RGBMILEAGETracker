# WC-10 Data/Order Migration Evidence Report

**Build:** `v2.1.6l-wc10`  
**Status:** NOT YET COMPLETED

## Source provenance

- Source archive:
- Archive SHA-256:
- Core hashes:
- Fresh extraction:

## Automated test environment

- Runtime:
- Test command:
- Test-harness version:
- Fixture hashes:

## Migration results

- MT-01:
- MT-02:
- MT-03:
- MT-04:
- MT-05:
- MT-06:
- MT-07:
- MT-08:
- MT-09:
- MT-10:
- MT-11:
- MT-12:

## Reorder results

- OT-01 through OT-07:

## Restore results

- RT-01 through RT-08:

## Transaction/recovery results

- TX-01 through TX-05:

## Deterministic integrity evidence

- Existing vehicle IDs before/after:
- Record counts by vehicle ID:
- Record ownership hashes:
- Order before/after:
- Second migration comparison:
- Legacy key retained:

## Conclusion

- Overall result:
- Failed tests:
- Data-layer implementation authorization:
- Next authorized gate:
