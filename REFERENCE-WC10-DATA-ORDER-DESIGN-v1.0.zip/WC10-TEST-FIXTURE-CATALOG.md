# WC-10 Test Fixture Catalog

**Version:** 1.0

Synthetic fixtures are included under `fixtures/`.

## Included fixtures

- `legacy-two-configured.json`
- `legacy-one-configured-one-null.json`
- `legacy-two-null.json`
- `legacy-reversed-slots.json`
- `valid-v3-three-vehicles.json`
- `invalid-four-vehicles.json`
- `invalid-duplicate-vehicle-ids.json`
- `invalid-orphan-record.json`
- `restore-reordered-three-vehicles.json`
- `expected-results.json`

Fixtures contain no user data.

## Fixture rules

- IDs are synthetic and deterministic.
- Operational records are minimal but preserve ownership relationships.
- Failure fixtures must never be silently repaired in a way that loses data.
- Expected results define vehicle IDs, order, configured states, record counts, and acceptance outcome.
