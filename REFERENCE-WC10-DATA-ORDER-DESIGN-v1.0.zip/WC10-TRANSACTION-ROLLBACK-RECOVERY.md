# WC-10 Transaction, Rollback, and Recovery Design

**Version:** 1.0  
**Status:** APPROVED

## Storage sequence

1. Read source state.
2. Preserve source key and raw serialized value.
3. Run migration in memory.
4. Validate migrated state.
5. Serialize migrated state.
6. Write a pending key:

```text
RGBM_DATA_v3_pending
```

7. Read pending value back and validate again.
8. Write active key:

```text
RGBM_DATA_v3
```

9. Remove pending key.
10. Retain legacy source key as rollback evidence.
11. Record completed migration metadata.

## Atomicity model

`localStorage.setItem()` is atomic per key, but the multi-key procedure is treated as a transaction through validation and pending-key promotion.

## Failure behavior

On any failure:

- active legacy data remains unchanged
- pending data is removed when safe
- no partial canonical state is treated as active
- an actionable error is shown
- diagnostics record the failure stage and code
- private vehicle details are not copied into error logs

## Recovery

At startup:

- valid active v3 key wins
- invalid active v3 key triggers recovery prompt
- valid pending key may be validated and promoted only through the recovery flow
- legacy v2 key remains available for controlled rollback
