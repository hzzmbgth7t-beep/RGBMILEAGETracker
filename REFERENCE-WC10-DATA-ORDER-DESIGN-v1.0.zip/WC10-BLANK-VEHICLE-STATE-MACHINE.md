# WC-10 Blank Vehicle State Machine

**Version:** 1.0  
**Status:** APPROVED

## States

### Unconfigured

```text
setupComplete = false
```

Behavior:

- label: `Add Vehicle`
- visual: empty circle with restrained plus symbol
- tap: open vehicle setup
- long press: open vehicle setup or blank details; never fuel entry
- operational entry: blocked
- import target: excluded
- report totals: excluded

### Editing unconfigured

The user may enter identity, image, and acquisition information.

Cancel:

- returns to Home
- leaves the record unconfigured
- creates no acquisition record
- creates no operational records

Save with invalid identity:

- remains on setup
- shows a meaningful validation message
- does not set `setupComplete`

Save with valid identity:

- sets `setupComplete:true`
- updates display name
- saves image when supplied
- creates acquisition record only when acquisition fields are meaningful

### Configured

```text
setupComplete = true
```

Behavior:

- Home tap follows normal configured-vehicle behavior
- vehicle is available in selectors and reports
- operational records may be created

### Reset or archive

No new destructive reset behavior is authorized by this package.

Existing archive behavior may be preserved. Returning a configured vehicle to the blank state requires a separately approved destructive-data rule.
