# WC-10 Restore and Merge Design

**Version:** 1.0  
**Status:** APPROVED

## Mandatory rule

Vehicle definitions are matched and merged by `vehicleId`, never by array index.

## Replace mode

1. Validate incoming backup structure.
2. Migrate incoming data to v3 in memory.
3. Validate complete migrated state.
4. Commit atomically as the new active state.
5. Preserve the pre-restore active state as rollback data.

## Update mode

- Matching vehicle IDs: update supported fields.
- Unmatched configured incoming vehicle:
  - consume one local unconfigured blank position when capacity exists
  - preserve incoming ID
- Unmatched incoming vehicle with no available blank:
  - fail with a capacity conflict
- Incoming order does not silently override local order.
- Offer explicit order adoption as a separate confirmed action.

## Skip mode

- Existing matching vehicles remain unchanged.
- Unmatched configured incoming vehicle may consume a blank position.
- Capacity conflicts fail explicitly.

## Duplicate mode

Duplicate mode applies only to operational records.

Vehicle definitions are never duplicated automatically because duplicating identity would also require remapping every associated record.

## Operational records

- Match by stable record ID.
- Preserve `vehicleId`.
- Reject records whose vehicle ID is absent after vehicle merge.
- Do not remap records according to display position.

## Order restore

Order is restored separately from vehicle definitions.

A proposed incoming order must:

- contain three unique known IDs
- contain the same vehicle-ID set as the merged state
- be explicitly accepted for Update or Skip modes
- be automatically used for Replace mode after validation
