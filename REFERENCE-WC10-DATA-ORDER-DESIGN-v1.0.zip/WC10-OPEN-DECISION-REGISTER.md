# WC-10 Data/Order Open Decision Register

**Version:** 1.0

## Data/order design status

No blocking data/order architecture decisions remain open.

The following decisions are explicitly locked:

- schema version `3.0.0`
- migration version `wc10-three-vehicle-v1`
- active key `RGBM_DATA_v3`
- pending key `RGBM_DATA_v3_pending`
- retained legacy key `RGBM_DATA_v213d`
- exactly three explicit vehicle records
- stable `vehicleId`
- separate `vehicleOrder`
- blank state through `setupComplete:false`
- restore by ID
- no silent truncation
- no fabricated acquisition record
- no destructive reset-to-blank behavior

## Deferred outside this package

These do not block data-layer implementation:

- exact portrait circle size ratio
- exact device-calibrated spacing constants
- final Home CSS selectors
- chrome styling
- landscape geometry implementation
