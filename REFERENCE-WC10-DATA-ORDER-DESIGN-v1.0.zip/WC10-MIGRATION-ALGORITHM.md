# WC-10 Migration Algorithm

**Version:** 1.0  
**Status:** APPROVED

## Pure migration contract

```text
migrateToV3(rawState, context) -> {
  state,
  report
}
```

The function must not write storage or mutate its input.

## Algorithm

```text
1. Deep-clone rawState.
2. Detect source schema and source key.
3. If already valid schema 3.0.0:
     validate and return unchanged canonical state.
4. Normalize root arrays and supported settings.
5. Read all legacy vehicle objects without slice/truncation.
6. Reject more than three unique source vehicles.
7. Normalize configured legacy vehicles.
8. Assign IDs only to vehicles missing IDs.
9. Convert legacy null positions to explicit blank records.
10. Derive order:
      valid vehicleOrder
      else unique legacy slots
      else source-array order
11. Add blank records until exactly three vehicles exist.
12. Remove legacy slot from canonical vehicle objects.
13. Normalize operational records without changing vehicleId.
14. Migrate acquisition fields only for matching vehicle IDs.
15. Validate every record reference.
16. Validate unique record IDs where required.
17. Set schemaVersion 3.0.0.
18. Set migrationVersion wc10-three-vehicle-v1.
19. Append migrationHistory entry.
20. Run full canonical validation.
21. Return state and deterministic migration report.
```

## Idempotency

Running migration against valid v3 data:

- creates no new IDs
- creates no new vehicles
- changes no order
- creates no acquisition records
- changes no operational record ownership
- does not append a duplicate migration-history entry

## Rejection conditions

Migration returns failure and no committed state when:

- more than three unique vehicles exist
- duplicate vehicle IDs cannot be resolved safely
- operational records reference unknown vehicle IDs
- canonical validation fails
- serialization fails
- storage capacity prevents safe commit
