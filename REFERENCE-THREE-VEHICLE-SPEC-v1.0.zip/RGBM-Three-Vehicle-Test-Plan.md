# Three-Vehicle Test Plan

**Version:** 1.0  
**Status:** APPROVED

## Test stages

### Stage 1 — Baseline provenance
- Extract `v2.1.6l` fresh.
- Record source archive and core-file hashes.
- Confirm no failed working-copy source is used.

### Stage 2 — Migration
- Test production-like two-vehicle data.
- Test empty histories.
- Test large histories.
- Test missing optional image.
- Run migration twice.
- Compare IDs, counts, associations, and order.

### Stage 3 — Blank setup
- Confirm `Add Vehicle`.
- Confirm no inherited data.
- Add title only.
- Add image only.
- Add title and image.
- Replace image.
- Cancel setup without saving.

### Stage 4 — Reorder
Test all six permutations:

```text
ABC, ACB, BAC, BCA, CAB, CBA
```

Verify portrait, landscape, restart, and relaunch.

### Stage 5 — Home layout
- portrait large top/two equal lower
- landscape three equal across
- long titles
- missing images
- selected/unselected states
- maximum valid sizing

### Stage 6 — Non-Home
- Reports
- Data
- Settings
- vehicle selectors
- import/export
- backup/restore
- diagnostics

### Stage 7 — Regression
- existing mileage entry
- existing service records
- existing insurance data
- existing images
- selected vehicle
- current order
- app startup and routing

### Stage 8 — Artifact
- identity
- documentation
- URLs
- complete source tree
- archive integrity
- recipient access
