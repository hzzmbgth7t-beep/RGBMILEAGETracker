# RGB Mileage Three-Vehicle Expansion Specification

**Version:** 1.0  
**Date:** 2026-07-25  
**Status:** APPROVED FOR IMPLEMENTATION PLANNING  
**Locked baseline:** `v2.1.6l`  
**Reserved implementation working copy:** `v2.1.6l-wc10`  
**SP-01:** TABLED  
**WC-09:** RESERVED FOR TABLED SHELL WORK

## Purpose

Expand RGB Mileage from two vehicles to three while preserving every existing record, retaining reorderable positions, and introducing a blank third vehicle that can be configured later.

## Locked layout

### Portrait

- Position 1: one large centered vehicle unit.
- Positions 2 and 3: two equal smaller vehicle units below.
- Position determines size; vehicle identity does not.
- Each unit moves as circle, image, title, identity, and selection behavior.

```text
              Position 1
          large circle + label

Position 2                     Position 3
smaller circle + label         smaller circle + label
```

### Landscape

- Three equal vehicle units in one horizontal row.
- All circles use the same maximum valid shared diameter.
- Left-to-right order matches persisted order.

## Blank third vehicle

Migration appends one blank vehicle record with:

- no title
- no image
- no mileage, service, or insurance records
- no inherited values
- no copied settings

Visible state:

- empty circle
- restrained plus symbol
- `Add Vehicle`
- selection opens setup

After a valid save, the entered title and image replace the blank state.

## Reordering

- Extend current reorder behavior to three vehicles.
- Persist an ordered list of stable vehicle IDs.
- Portrait index 0 is large top; indexes 1 and 2 are lower left/right.
- Landscape indexes 0, 1, and 2 are left, center, and right.
- Reordering never changes IDs or associated records.
- A non-drag reorder method is mandatory.

## Migration

The migration must:

- preserve both existing IDs
- preserve every associated record and image
- preserve existing order
- append one blank third vehicle
- run once
- be idempotent
- update import/export and backup compatibility
- fail safely without destroying original data

## Geometry

### Portrait

Calculate the maximum valid top diameter and maximum valid equal lower diameter while preserving:

- fixed title/version clearance
- top circle/label clearance
- top label/lower row clearance
- lower circle/label clearance
- lower label/dock clearance
- side safe-area clearance
- lower inter-unit clearance
- non-overlapping touch targets
- a visibly larger top circle

### Landscape

```text
width_limit =
  (usable_width - side_clearances - 2 * inter_unit_gap) / 3

height_limit =
  usable_height - header_region - label_region - dock_clearance

diameter = min(width_limit, height_limit)
```

All three circles use that diameter.

## Titles

- Portrait: up to two lines.
- Landscape: one line.
- Ellipsis only after the line limit.
- Text may not shrink below the approved readable minimum.

## Images

- preserve aspect ratio
- center-crop consistently
- never stretch
- handle missing or invalid files safely
- prevent stale image display after replacement
- blank vehicle inherits no image

## Selection

Selection may change border, highlight, or shadow. It may not change diameter, position, or neighboring geometry.

## Non-Home support

Update Reports, Data, Settings, selectors, imports, exports, backups, diagnostics, and summaries. Audit all fixed two-vehicle assumptions.

## Accessibility

- whole unit is selectable
- touch targets do not overlap
- blank unit accessible name is `Add Vehicle`
- reorder has non-drag controls
- focus order follows persisted order

## Scope

Included: model, migration, reorder, blank setup, three-vehicle Home layout, non-Home support, import/export, regression testing.

Excluded: SP-01 execution, WC-09 shell implementation, unrelated redesign.

## Implementation order

1. Fresh `v2.1.6l` extraction
2. Baseline provenance
3. Data migration
4. Migration regression tests
5. Reorder and persistence
6. Blank setup flow
7. Non-Home support
8. Portrait layout
9. Landscape layout
10. Geometry maximization
11. Accessibility
12. Real-device testing
13. Governed handoff

## Promotion rule

No promotion unless migration, existing-data preservation, blank state, reorder, portrait, landscape, non-Home screens, import/export, accessibility, documentation, and archive gates all pass.
