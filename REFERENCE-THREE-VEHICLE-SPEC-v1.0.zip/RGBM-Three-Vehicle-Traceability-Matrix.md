# Three-Vehicle Traceability Matrix

| Requirement | Specification area | Required verification |
|---|---|---|
| TV-FR-01 | Data migration | Post-migration record count |
| TV-FR-02 | Migration integrity | ID and association comparison |
| TV-FR-03 | Blank defaults | Storage inspection |
| TV-FR-04 | Blank UI | Portrait/landscape screenshot |
| TV-FR-05 | Setup navigation | Functional test |
| TV-FR-06 | Save isolation | Record ownership test |
| TV-FR-07 | Reorder | Three-position functional test |
| TV-FR-08 | Persistence | Restart/relaunch test |
| TV-FR-09 | Portrait geometry | Device screenshot + measurements |
| TV-FR-10 | Portrait lower equality | Diameter comparison |
| TV-FR-11 | Landscape row | Device screenshot |
| TV-FR-12 | Maximum diameter | Geometry diagnostics |
| TV-FR-13 | Non-Home support | Screen/import/export matrices |
| TV-FR-14 | Selection invariant | Before/after geometry |
| TV-FR-15 | Label handling | Long-title tests |
| TV-FR-16 | Image handling | Aspect/crop/replacement tests |
| TV-FR-17 | Unit integrity | Reorder data audit |
| TV-NFR-03 | Idempotency | Repeated migration test |
| TV-NFR-04 | No data loss | Pre/post hashes and counts |
| TV-NFR-06 | Non-drag reorder | Accessibility test |
| TV-NFR-07 | Documentation | Compliance audit |
