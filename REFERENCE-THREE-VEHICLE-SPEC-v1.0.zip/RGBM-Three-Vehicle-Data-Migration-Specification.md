# Three-Vehicle Data Migration Specification

**Version:** 1.0  
**Status:** APPROVED

## Source state

- two existing vehicle records
- stable unique IDs
- associated mileage, service, insurance, image, and settings data
- persisted display order

## Target state

- three vehicle records
- original IDs unchanged
- all associations unchanged
- original order retained
- one blank record appended at position 3

## Blank defaults

- unique ID
- title empty
- image empty
- mileage/service/insurance arrays empty
- setupComplete false
- display order 3
- no copied metadata

## Idempotency

- migrate only pre-three-vehicle schema
- do not duplicate an existing blank third record
- do not append when three configured vehicles already exist
- record migration version

## Integrity checks

Compare before and after:

- IDs
- counts by vehicle ID
- image references
- selected vehicle
- order
- settings associations
- export structure

## Failure behavior

- preserve original storage
- do not silently continue
- show meaningful error
- permit backup restoration
- record diagnostics without exposing private data
