# Build Documentation Policy

**Version:** 1.0  
**Status:** MANDATORY

Every build of any type must include its complete governed documentation.

A build fails and must be withheld when a mandatory document is missing, incomplete, inconsistent with identity, absent from the archive, or omitted from the compliance audit.

This applies to specifications, plans, probes, working copies, diagnostic builds, full installs, and governance packages.
