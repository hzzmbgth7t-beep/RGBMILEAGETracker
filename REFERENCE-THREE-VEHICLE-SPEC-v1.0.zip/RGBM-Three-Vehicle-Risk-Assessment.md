# Three-Vehicle Risk Assessment

**Version:** 1.0

| Risk | Impact | Mitigation |
|---|---|---|
| Existing records attach to wrong vehicle | Critical | Preserve IDs; compare counts and associations before/after |
| Migration creates duplicate third vehicle | High | Idempotent migration version and duplicate guard |
| Blank vehicle inherits data | Critical | Explicit empty defaults and association audit |
| Reorder changes identity | Critical | Persist ordered IDs, never positional data ownership |
| Non-Home screens remain two-vehicle | High | Repository-wide hard-coded assumption audit |
| Import/export loses third vehicle | High | Schema versioning and round-trip tests |
| Portrait circles become too small | Medium | Maximum-valid geometry and device matrix |
| Landscape leaves unused space | Medium | Width/height formula and measured constraints |
| Long labels overlap | Medium | Locked line limits and readable minimum |
| Image replacement shows stale image | Medium | Cache-busting or storage reference update |
| Touch targets overlap | High | Geometry and accessibility verification |
| Documentation omitted | High | Build-blocking documentation audit |

## Stop conditions

Stop implementation or handoff when:

- baseline provenance is not proven
- migration cannot preserve IDs
- pre/post data counts do not match
- a two-vehicle assumption remains unresolved
- device evidence is unavailable for layout acceptance
- any mandatory document or archive gate fails
