# Three-Vehicle Verification Matrix

**Allowed results:** PASS, FAIL, N/A

## Migration

| ID | Requirement | Result |
|---|---|---|
| M-01 | Original IDs unchanged | PENDING |
| M-02 | Existing records remain correctly associated | PENDING |
| M-03 | Exactly one blank third record | PENDING |
| M-04 | Second migration creates no duplicate | PENDING |
| M-05 | Existing order preserved | PENDING |
| M-06 | Failure path preserves source data | PENDING |

## Reorder

| ID | Requirement | Result |
|---|---|---|
| R-01 | All six permutations work | PENDING |
| R-02 | Order persists after restart | PENDING |
| R-03 | Order persists after standalone relaunch | PENDING |
| R-04 | Portrait mapping is correct | PENDING |
| R-05 | Landscape mapping is correct | PENDING |
| R-06 | Non-drag controls work | PENDING |

## Portrait

| ID | Requirement | Result |
|---|---|---|
| P-01 | Position 1 is large and centered | PENDING |
| P-02 | Lower circles are equal | PENDING |
| P-03 | Top circle is maximum valid size | PENDING |
| P-04 | Lower circles are maximum valid size | PENDING |
| P-05 | Labels and units do not overlap | PENDING |
| P-06 | Lower labels clear dock | PENDING |
| P-07 | Blank state is clear and selectable | PENDING |

## Landscape

| ID | Requirement | Result |
|---|---|---|
| L-01 | Three units appear in one row | PENDING |
| L-02 | All diameters are equal | PENDING |
| L-03 | Shared diameter is maximum valid | PENDING |
| L-04 | Side and inter-unit clearances pass | PENDING |
| L-05 | Labels clear header and dock | PENDING |

## Non-Home

| ID | Requirement | Result |
|---|---|---|
| N-01 | Reports support all three | PENDING |
| N-02 | Data supports all three | PENDING |
| N-03 | Settings supports setup/reorder | PENDING |
| N-04 | Export/import round-trip passes | PENDING |
| N-05 | Legacy import migration passes | PENDING |
| N-06 | Backup/restore passes | PENDING |

## Accessibility and regression

| ID | Requirement | Result |
|---|---|---|
| A-01 | Touch targets do not overlap | PENDING |
| A-02 | Accessible names and focus order pass | PENDING |
| A-03 | Selected state is not color-only | PENDING |
| G-01 | Existing two-vehicle behavior remains intact | PENDING |
| G-02 | No unresolved two-vehicle assumptions remain | PENDING |
