# Three-Vehicle Layout and Geometry Specification

**Version:** 1.0  
**Status:** APPROVED

## Portrait

- one centered large top unit
- two equal lower units
- title placement independent from circle size
- every clearance is an explicit governed constant

### Top diameter limits

- usable width
- header boundary
- own-label area
- lower-row boundary

### Lower diameter limits

- half usable width
- lower inter-unit gap
- own-label area
- dock clearance
- lower-row height

The top unit remains visibly larger, and both regions use their maximum valid diameters.

## Landscape

- three units in one horizontal row
- equal shared diameter
- order left to right

```text
horizontal_limit =
  floor((usable_width - left_clearance - right_clearance
         - 2 * inter_unit_gap) / 3)

vertical_limit =
  usable_height - header_region - own_label_gap
  - label_height - dock_clearance

diameter = min(horizontal_limit, vertical_limit)
```

## Invariants

- width equals height
- no asymmetric scaling
- label remains inside the vehicle unit
- selection never changes geometry
- no overlap or dock contact
- no unexplained unused area after all constraints bind
