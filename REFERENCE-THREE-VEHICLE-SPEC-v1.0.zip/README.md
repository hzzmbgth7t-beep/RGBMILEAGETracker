# RGBM Three-Vehicle Expansion Specification Package

**Version:** 1.0  
**Date:** 2026-07-25  
**Status:** Complete governed specification package

## Purpose

Define the complete requirements, architecture, migration, layout, reorder, non-Home impact, testing, evidence, and governance for adding a third vehicle.

## Identity

- Locked baseline: `v2.1.6l`
- Three-vehicle implementation: `v2.1.6l-wc10`
- WC-09: reserved for tabled shell work
- SP-01: tabled

## Package status

This package authorizes WC-10 implementation planning. It does not claim that implementation or device acceptance has occurred.
