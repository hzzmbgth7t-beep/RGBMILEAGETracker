# Three-Vehicle Specification Document Index

| Document | Purpose |
|---|---|
| README.md | Package identity and purpose |
| BUILD-DOCUMENTATION-POLICY.md | Mandatory documentation rule |
| RGBM-Three-Vehicle-Expansion-Specification.md | Governing specification |
| RGBM-Three-Vehicle-Requirements.md | Functional/nonfunctional requirements |
| RGBM-Three-Vehicle-Acceptance-Criteria.md | PASS/FAIL conditions |
| RGBM-Three-Vehicle-Data-Migration-Specification.md | Migration and integrity |
| RGBM-Three-Vehicle-Layout-and-Geometry-Specification.md | Portrait/landscape geometry |
| RGBM-Three-Vehicle-Reorder-and-Persistence-Specification.md | Ordering model |
| RGBM-Three-Vehicle-Non-Home-Impact-Specification.md | Reports/Data/Settings/import/export |
| RGBM-Three-Vehicle-Accessibility-Specification.md | Accessibility requirements |
| RGBM-Three-Vehicle-Assumptions-and-Constraints.md | Boundaries and unknowns |
| RGBM-Three-Vehicle-Risk-Assessment.md | Risks and stop conditions |
| RGBM-Three-Vehicle-Architecture-Decisions.md | Accepted ADRs |
| RGBM-Three-Vehicle-Traceability-Matrix.md | Requirement mapping |
| RGBM-Three-Vehicle-Implementation-Plan.md | WC-10 sequence |
| RGBM-Three-Vehicle-Test-Plan.md | Test stages |
| RGBM-Three-Vehicle-Verification-Matrix.md | Required result matrix |
| RGBM-Three-Vehicle-Evidence-Report-Template.md | Evidence record |
| RGBM-Three-Vehicle-Open-Decision-Register.md | Questions requiring evidence |
| RGBM-Three-Vehicle-Executive-Highlights.md | Concise summary |
| RGBM-Three-Vehicle-Change-Log.md | Changes |
| RGBM-Three-Vehicle-Version-History.md | Version lineage |
| RGBM-Three-Vehicle-Handoff-and-Authorization.md | Authorized next step |
| RGBM-Three-Vehicle-Governance-Compliance-Checklist.md | Governance check |
| ARCHIVE-MANIFEST.json | File inventory and hashes |
| FULL-COMPLIANCE-AUDIT.txt | Artifact-level compliance result |
