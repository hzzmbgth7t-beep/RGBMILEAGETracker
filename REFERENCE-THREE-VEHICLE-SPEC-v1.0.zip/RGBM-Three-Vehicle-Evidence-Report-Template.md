# Three-Vehicle Evidence Report

**Build:** `v2.1.6l-wc10`  
**Status:** NOT YET COMPLETED

## Baseline provenance
- Source archive:
- Source SHA-256:
- Core-file hashes:
- Fresh extraction confirmed:

## Test environment
- Device:
- iOS version:
- Display mode:
- Orientation:
- Exact deployed URL:
- Cache-buster URL:
- Installation/reinstall state:

## Migration evidence
- Before IDs/counts:
- After IDs/counts:
- Idempotency result:
- Association audit:
- Backup/restore result:

## Reorder evidence
- Permutations tested:
- Restart result:
- Relaunch result:
- Portrait mapping:
- Landscape mapping:

## Portrait evidence
- Screenshot:
- Diagnostics:
- Matrix results:

## Landscape evidence
- Screenshot:
- Diagnostics:
- Matrix results:

## Non-Home evidence
- Reports:
- Data:
- Settings:
- Import/export:
- Backup/restore:

## Accessibility evidence
- Touch targets:
- Accessible names:
- Focus order:
- Non-drag reorder:

## Conclusion
- Overall result:
- Failed requirements:
- Supporting evidence:
- Recommended next action:
