# Three-Vehicle Reorder and Persistence Specification

**Version:** 1.0  
**Status:** APPROVED

## Model

Persist an ordered list of stable vehicle IDs.

```text
[vehicleIdA, vehicleIdB, vehicleIdC]
```

Position is not identity.

## Controls

- drag-and-drop may be retained
- move up/down or explicit position controls are mandatory
- all controls update the same ordered ID list

## Layout mapping

Portrait:

- index 0 → large top
- index 1 → lower left
- index 2 → lower right

Landscape:

- index 0 → left
- index 1 → center
- index 2 → right

## Persistence tests

Verify after:

- page navigation
- orientation change
- app restart
- standalone relaunch
- export/import round trip

Active selection remains tied to vehicle ID.
