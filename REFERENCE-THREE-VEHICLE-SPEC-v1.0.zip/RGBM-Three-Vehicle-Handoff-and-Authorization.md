# Three-Vehicle Specification Handoff and Authorization

**Artifact type:** Governed specification  
**Version:** 1.0  
**Date:** 2026-07-25

## Authorized

- WC-10 implementation planning
- fresh-baseline provenance audit
- repository audit for two-vehicle assumptions
- migration design based on verified baseline schema

## Not yet authorized by this package

- promotion
- production deployment
- device acceptance claims
- reuse of failed working-copy code
- changes to SP-01 or WC-09
- destructive vehicle delete/reset behavior without approval

## Next implementation gate

Create the WC-10 baseline provenance and impact-audit package before modifying application code.
