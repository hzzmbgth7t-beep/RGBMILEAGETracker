# Three-Vehicle Specification Change Log

## v1.0 — 2026-07-25

- Tabled SP-01.
- Reserved WC-09 for shell work.
- Reserved WC-10 for three-vehicle expansion.
- Locked portrait and landscape arrangements.
- Locked reorder and blank third-vehicle behavior.
- Added migration, non-Home, accessibility, testing, evidence, and governance requirements.
