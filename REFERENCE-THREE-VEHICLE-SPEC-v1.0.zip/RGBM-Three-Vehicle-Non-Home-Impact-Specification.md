# Three-Vehicle Non-Home Impact Specification

**Version:** 1.0  
**Status:** APPROVED

## Source audit targets

Search for:

- fixed two-element arrays
- vehicle 1 / vehicle 2 branching
- two-button selectors
- two-color maps
- loops capped at two
- reports with two columns
- exports expecting two records
- settings with two fixed sections

## Reports

- filter/select all three
- correct totals per ID
- blank vehicle creates no fabricated records

## Data

- show three identities
- preserve record ownership
- blank vehicle shows an empty state

## Settings

- configure third vehicle
- reorder all three
- update title/image
- define reset/delete behavior explicitly

## Import/export

- update schema version
- round-trip three vehicles
- migrate legacy two-vehicle exports safely
- reject malformed imports meaningfully

## Backup/restore

- preserve third vehicle
- preserve order
- preserve original IDs
