# Three-Vehicle Requirements

**Version:** 1.0  
**Status:** APPROVED

## Functional

- TV-FR-01: Support exactly three vehicle slots after migration.
- TV-FR-02: Preserve both existing vehicle identities and records.
- TV-FR-03: Add one blank third vehicle.
- TV-FR-04: Display `Add Vehicle` for the blank record.
- TV-FR-05: Open setup from the blank unit.
- TV-FR-06: Save title and image only to the third vehicle.
- TV-FR-07: Reorder all three vehicle positions.
- TV-FR-08: Persist order after restart.
- TV-FR-09: Portrait position 1 is large.
- TV-FR-10: Portrait positions 2 and 3 are equal smaller units.
- TV-FR-11: Landscape displays three equal circles horizontally.
- TV-FR-12: Landscape maximizes valid shared diameter.
- TV-FR-13: Reports, Data, Settings, import, export, and backup support three vehicles.
- TV-FR-14: Selection styling does not change geometry.
- TV-FR-15: Titles follow locked wrapping rules.
- TV-FR-16: Images crop without distortion.
- TV-FR-17: Reordering moves the entire vehicle unit.

## Nonfunctional

- TV-NFR-01: Start from fresh `v2.1.6l`.
- TV-NFR-02: Do not reuse failed working-copy code.
- TV-NFR-03: Migration is idempotent.
- TV-NFR-04: Existing data loss is prohibited.
- TV-NFR-05: Touch targets do not overlap.
- TV-NFR-06: Reorder supports non-drag controls.
- TV-NFR-07: Every build contains complete documentation.
- TV-NFR-08: Static, runtime, device, and artifact audits remain separate.
- TV-NFR-09: Acceptance results are PASS, FAIL, or N/A.
