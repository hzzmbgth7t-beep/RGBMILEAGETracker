# Three-Vehicle Acceptance Criteria

**Version:** 1.0  
**Allowed results:** PASS, FAIL, N/A

## Data and migration

- AC-D01: Existing vehicle IDs are unchanged.
- AC-D02: Existing mileage, service, insurance, image, and settings records remain attached to the correct IDs.
- AC-D03: Exactly one blank third vehicle is appended.
- AC-D04: Re-running migration creates no duplicate.
- AC-D05: Original order is preserved.
- AC-D06: Migration failure does not destroy source data.

## Blank vehicle

- AC-B01: Blank circle has no inherited image.
- AC-B02: Blank title is `Add Vehicle`.
- AC-B03: Selecting it opens setup.
- AC-B04: Saving title/image updates only the new ID.
- AC-B05: No fabricated records exist.

## Reorder

- AC-R01: Three vehicles can be reordered.
- AC-R02: Order persists after restart and relaunch.
- AC-R03: Portrait and landscape map the same order correctly.
- AC-R04: Reorder never changes record ownership.
- AC-R05: Non-drag reorder works.

## Portrait

- AC-P01: Position 1 is visibly larger.
- AC-P02: Positions 2 and 3 are equal.
- AC-P03: Units do not overlap.
- AC-P04: Labels remain attached.
- AC-P05: Lower labels clear the dock.
- AC-P06: Circles use maximum valid space.

## Landscape

- AC-L01: Three units form one row.
- AC-L02: All circles have equal diameter.
- AC-L03: Diameter is maximum valid shared value.
- AC-L04: Side, inter-unit, title, label, and dock clearances pass.

## Non-Home

- AC-N01: Reports support three vehicles.
- AC-N02: Data supports three vehicles.
- AC-N03: Settings supports setup and reorder.
- AC-N04: Import/export round-trip preserves all three.
- AC-N05: Two-vehicle legacy exports migrate safely.

## Build

- AC-G01: Complete documentation is present.
- AC-G02: Archive integrity passes.
- AC-G03: Full install contains all required files.
- AC-G04: Build identity is consistent.
