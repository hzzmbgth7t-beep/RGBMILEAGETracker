# Three-Vehicle Accessibility Specification

**Version:** 1.0  
**Status:** APPROVED

- Whole vehicle unit is selectable.
- Blank unit accessible name is `Add Vehicle`.
- Vehicle images use meaningful accessible text or are decorative when the title supplies identity.
- Touch targets do not overlap.
- Reordering has keyboard/non-drag alternatives.
- Focus order follows persisted vehicle order.
- Portrait focus order: top, lower left, lower right.
- Landscape focus order: left, center, right.
- Selected state is not communicated by color alone.
- Text does not shrink below the governed readable minimum.
