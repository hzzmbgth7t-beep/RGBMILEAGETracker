# Three-Vehicle Assumptions and Constraints

**Version:** 1.0

## Assumptions

- The locked source baseline is `v2.1.6l`.
- Existing vehicle IDs are stable and used by associated records.
- Current reorder behavior can be generalized without redefining identity.
- The user will configure the third vehicle after deployment.
- iPhone 17 Pro Max is the controlling real-device target.

## Constraints

- WC-09 remains reserved for tabled shell work.
- WC-10 is reserved for three-vehicle implementation.
- Failed working-copy code is not reusable.
- SP-01 remains tabled and separate.
- Existing data loss is prohibited.
- The blank third vehicle may not inherit another vehicle's data.
- Documentation compliance is mandatory for every build.
- Acceptance language is PASS, FAIL, or N/A.

## Open implementation questions

These must be resolved during WC-10 planning, not guessed:

- exact current storage schema and migration hook
- exact existing reorder control implementation
- delete/reset behavior for the third vehicle
- import schema version and backward-compatibility mechanism
- image-storage and cache-invalidation mechanism
