# Three-Vehicle Implementation Plan

**Version:** 1.0  
**Target working copy:** `v2.1.6l-wc10`

## Phase A — Source gate
- Fresh baseline extraction.
- Provenance and file-hash report.
- Repository audit for two-vehicle assumptions.

## Phase B — Data layer
- Introduce schema/migration version.
- Append blank third vehicle.
- Preserve IDs and associations.
- Add idempotency guards.
- Update import/export and backups.

## Phase C — Reorder
- Generalize ordered ID list to three.
- Preserve existing behavior.
- Add non-drag controls.
- Verify persistence.

## Phase D — Setup flow
- Render `Add Vehicle`.
- Open setup from blank unit.
- Save title/image to new ID.
- Preserve blank state on cancel.

## Phase E — Non-Home
- Update Reports, Data, Settings, selectors, diagnostics, and summaries.
- Remove hard-coded two-vehicle assumptions.

## Phase F — Home layout
- Portrait: one large top, two equal lower.
- Landscape: three equal horizontal.
- Preserve complete vehicle-unit movement.

## Phase G — Geometry
- Measure available regions.
- Calculate maximum valid diameters.
- Recalculate on orientation/viewport changes.
- Emit diagnostics.

## Phase H — Accessibility and regression
- Touch targets, names, focus, reorder controls.
- Existing-record and app-function regression.

## Phase I — Handoff
- Complete documentation.
- Full install ZIP.
- Static and archive audits.
- Device matrices.
- No promotion before all mandatory PASS results.
