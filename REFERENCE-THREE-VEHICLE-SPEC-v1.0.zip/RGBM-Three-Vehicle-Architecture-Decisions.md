# Three-Vehicle Architecture Decision Records

**Version:** 1.0

## ADR-TV-001 — Position is separate from identity

**Status:** Accepted  
Persist vehicle IDs in an ordered list. Never use position as record identity.

## ADR-TV-002 — Portrait position 1 is visually primary

**Status:** Accepted  
The first ordered vehicle occupies the large top unit. This is a layout role, not permanent vehicle metadata.

## ADR-TV-003 — Landscape vehicles are equal

**Status:** Accepted  
All three circles use one maximum valid shared diameter.

## ADR-TV-004 — Third vehicle begins blank

**Status:** Accepted  
The new record has no inherited title, image, or operational data.

## ADR-TV-005 — Blank state is actionable

**Status:** Accepted  
Display a restrained plus symbol and `Add Vehicle`; selection opens setup.

## ADR-TV-006 — Migration is idempotent

**Status:** Accepted  
Repeated startup cannot create additional blank vehicles.

## ADR-TV-007 — Reorder moves the complete unit

**Status:** Accepted  
Circle, image, title, identity, selection, and associated records remain together.

## ADR-TV-008 — Non-drag reorder is mandatory

**Status:** Accepted  
Accessibility and deterministic control require an alternative to drag-and-drop.

## ADR-TV-009 — SP-01 remains tabled

**Status:** Accepted  
Three-vehicle work must not alter or depend on the tabled probe.

## ADR-TV-010 — WC-10 is the implementation identifier

**Status:** Accepted  
WC-09 remains reserved for the tabled shell architecture work.
