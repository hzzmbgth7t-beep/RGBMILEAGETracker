# Three-Vehicle Expansion — Highlights

- SP-01 is tabled.
- WC-09 remains reserved for shell work.
- Three-vehicle implementation is assigned to `v2.1.6l-wc10`.
- Portrait uses one large top circle and two equal smaller circles below.
- Landscape uses three equal circles at the maximum valid shared diameter.
- Vehicle order remains changeable and persistent.
- Position controls size; identity and records stay tied to stable IDs.
- Migration preserves both existing vehicles and appends one blank third record.
- The blank record displays a plus symbol and `Add Vehicle`.
- Reports, Data, Settings, import/export, backups, and selectors must all support three vehicles.
- Migration and existing-data preservation are the highest-risk gates.
- Every build fails when documentation compliance fails.
