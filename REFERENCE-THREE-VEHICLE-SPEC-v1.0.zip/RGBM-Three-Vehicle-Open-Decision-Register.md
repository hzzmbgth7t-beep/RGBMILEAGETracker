# Three-Vehicle Open Decision Register

**Version:** 1.0

These questions require evidence from the locked baseline or an explicit product decision before their affected code is implemented.

| ID | Question | Current rule |
|---|---|---|
| OD-01 | What is the exact storage schema and migration entry point? | Inspect baseline; do not guess |
| OD-02 | How is current two-vehicle order stored? | Preserve and generalize existing mechanism |
| OD-03 | Can a configured vehicle be deleted/reset? | Do not add new destructive behavior without approval |
| OD-04 | What is the current import schema version? | Inspect baseline and create backward-compatible migration |
| OD-05 | How are images stored and invalidated? | Inspect baseline; prevent stale replacement images |
| OD-06 | What are the exact approved spacing constants? | Calibrate from accepted device references |
| OD-07 | What minimum ratio defines “large” versus lower circles? | Establish during WC-10 geometry planning and approve before device acceptance |

Open items do not permit assumptions. Each must be resolved, documented, and traced before the relevant implementation gate passes.
