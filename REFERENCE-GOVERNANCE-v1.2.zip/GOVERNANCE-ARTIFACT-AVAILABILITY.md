# Governance Artifact Availability and Flat-Upload Rule

**Governance version:** 1.2  
**Status:** APPROVED

A deliverable is complete only after:

1. the flat source folder is created
2. the source folder contains no subdirectories
3. the archive is created with root-level files only
4. the archive passes integrity verification
5. archive contents exactly match the intended flat source
6. every document is indexed and classified
7. the recipient can download the artifact
8. the recipient can upload every install file without creating folders
9. any UI presentation difference is recorded without inventing a cause

A filename link and a Download control are acceptable only after artifact compliance passes.
