# Governance v1.2 Changelog

**Governance version:** 1.2  
**Classification:** CURRENT  
**Status:** APPROVED

## v1.2 — 2026-07-25

- Added the universal flat install-folder rule.
- Prohibited every install subfolder and nested ZIP path.
- Required root-level documentation, tests, fixtures, references, and evidence.
- Added flattening filename-prefix rules.
- Added full flat-source and flat-archive audits.
- Required classification of every included document.
- Clarified that automated PASS cannot override packaging or device gates.
- Classified prior nested WC-10 packages as noncompliant.
