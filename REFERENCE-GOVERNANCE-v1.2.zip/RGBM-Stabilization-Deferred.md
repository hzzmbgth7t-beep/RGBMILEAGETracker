# Governance v1.2 Historical Classification

**Containing package:** `RGBM_Governance_v1.2_2026-07-25.zip`  
**Classification:** SUPERSEDED — HISTORICAL REFERENCE  
**Superseded by:** `RGBM-Universal-Release-and-Packaging-Rules.md` and later approved three-vehicle specifications  
**Controlling current implementation:** No

This document is retained only as historical evidence. Any two-vehicle, prior layout, or prior deferral rule in the text below is not controlling current three-vehicle implementation.

---

# RGBM Stabilization Deferred

**Governance version:** 1.1  
**Status:** APPROVED  
**Effective date:** 2026-07-10

## Deferred until D-HOME-001 closes

- reporting enhancements
- backup architecture redesign
- master-list administration changes
- non-Home visual redesign
- new feature development
- broad architecture changes
- cosmetic changes outside the Home/dock visual system
- nonessential documentation expansion

## Active and not deferred

The following remain part of D-HOME-001:

- portrait Dynamic Island title clearance
- landscape top-edge title clearance
- deterministic circle sizing
- vehicle-unit behavior
- fixed portrait and landscape clearances
- left/right landscape arrangement
- true bottom dock
- label chrome
- circle-border chrome
- portrait and landscape standalone verification

## Deferral gate

A deferred item may not be included in a Home/dock working copy.

A deferred item requires:

1. closure of D-HOME-001
2. a separate boundary memo
3. explicit approval
