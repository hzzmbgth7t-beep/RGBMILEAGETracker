# Governance v1.2 Document Index

**Status:** CURRENT  
**Package rule:** Every listed file is at the archive root.

| File | Classification | Purpose |
|---|---|---|
| RGBM-Universal-Release-and-Packaging-Rules.md | CURRENT | Controlling universal release and flat-package rules |
| GOVERNANCE-ARTIFACT-AVAILABILITY.md | CURRENT | Download and flat-upload availability |
| GOVERNANCE-v1.2-APPROVAL-REVIEW.md | CURRENT | Approval and prior-package effect |
| GOVERNANCE-v1.2-CHANGELOG.md | CURRENT | Governance changes |
| GOVERNANCE-VERSION-HISTORY.md | CURRENT | Version lineage |
| RGBM-Deterministic-Layout-Algorithm.md | SUPERSEDED — HISTORICAL REFERENCE | Prior two-vehicle layout algorithm |
| RGBM-Home-Dock-Verification-Matrix.md | SUPERSEDED — HISTORICAL REFERENCE | Prior Home/dock verification |
| RGBM-Home-Layout-Engineering-Model.md | SUPERSEDED — HISTORICAL REFERENCE | Prior two-vehicle engineering model |
| RGBM-Stabilization-Baseline.md | SUPERSEDED — HISTORICAL REFERENCE | Prior stabilization baseline |
| RGBM-Stabilization-Decisions.md | SUPERSEDED — HISTORICAL REFERENCE | Prior stabilization decisions |
| RGBM-Stabilization-Defects.md | SUPERSEDED — HISTORICAL REFERENCE | Prior defect register |
| RGBM-Stabilization-Deferred.md | SUPERSEDED — HISTORICAL REFERENCE | Prior deferral register |
| DOCUMENT-INDEX.md | CURRENT | Complete document classification and inventory |
| FLAT-PACKAGE-AUDIT.json | CURRENT | Machine-readable flat-source and flat-ZIP checks |
| ARCHIVE-MANIFEST.json | CURRENT | Root-level inventory and hashes |
| FULL-COMPLIANCE-AUDIT.txt | CURRENT | Internal artifact audit |
| HANDOFF-AUTHORIZATION.txt | CURRENT | Governance handoff |
