# RGBM Universal Release and Flat-Packaging Rules

**Governance version:** 1.2  
**Effective date:** 2026-07-25  
**Status:** APPROVED — UNIVERSAL AND BUILD-BLOCKING  
**Applies to:** every specification, audit, probe, working copy, test build, install build, deployment candidate, handoff, and promoted release

## 1. Universal release rule

Every new artifact or release must complete all required implementation, testing, documentation, packaging, audit, and handoff tasks for its declared phase.

A release is **FAIL** when any required item is:

- missing
- empty
- inconsistent
- outdated without an explicit historical classification
- absent from the archive
- absent from the document index
- absent from the manifest
- omitted from the compliance audit
- claimed as PASS without supporting evidence

Automated success does not override documentation, packaging, archive, deployment, or real-device failures.

## 2. Flat install-folder rule

Every install folder and every install ZIP must be completely flat.

### Mandatory

- All uploadable files are located at the install root.
- The ZIP contains no directory entries.
- No archived filename contains `/` or `\`.
- Runtime files, documentation, manifests, audits, evidence templates, and required test records are all root-level files.
- Filenames use clear prefixes to prevent collisions.

### Prohibited

- `docs/`
- `documentation/`
- `tests/`
- `fixtures/`
- `references/`
- `assets/`
- `images/`
- `src/`
- nested governance packages
- any other subfolder or nested path

A single nested file makes the entire release **FAIL**.

## 3. Flattening rules

When material would normally use a subfolder:

- Prefix documentation with the build or governance identifier.
- Prefix test files with `TEST-`.
- Prefix fixture files with `FIXTURE-`.
- Prefix reference files with `REFERENCE-`.
- Prefix evidence files with `EVIDENCE-`.
- Rename colliding files rather than placing them in separate directories.
- Record every renamed file in the document index and manifest.

Required reference packages may be included as separately named ZIP files at the root only when explicitly governed. They may not be silently unpacked into nested directories.

## 4. Install-folder audit

Every install artifact must prove:

1. the source folder contains no subdirectories
2. every source entry is a file
3. the ZIP contains no directory entries
4. every ZIP member name is a root-level basename
5. source filenames and archived filenames match exactly
6. required runtime files are present
7. required documentation is present
8. every document is indexed and classified
9. the manifest covers every archived file except itself under the governed self-hash rule
10. the internal audit and handoff files are inside the ZIP
11. the external audit reports the same package identity and hash

## 5. Documentation classification

Every document included in a release must be one of:

- `CURRENT`
- `SUPERSEDED — HISTORICAL REFERENCE`
- `N/A FOR THIS PHASE`

Unclassified legacy documents are prohibited.

A historical document must state:

- the current build or governance package containing it
- its historical status
- the document that supersedes it
- that it is not controlling current implementation

## 6. Real-device and deployment rules

When real-device evidence is required, it remains `N/A` until performed on the controlling device and environment.

A release may not use overall `PASS` to imply:

- device acceptance
- standalone acceptance
- deployment verification
- migration acceptance
- portrait acceptance
- landscape acceptance
- shell/dock acceptance

unless each applicable gate is actually PASS.

## 7. Handoff rule

Handoff is blocked when:

- flat-package compliance fails
- documentation compliance fails
- archive integrity fails
- package identity is inconsistent
- required evidence is missing
- any mandatory acceptance criterion is FAIL

## 8. Prior package status

Packages created before Governance v1.2 that contain subfolders are noncompliant with this rule and must not be promoted without rebuilding them as flat packages.
