# Governance v1.2 Approval Review

**Governance version:** 1.2  
**Classification:** CURRENT  
**Status:** APPROVED

**Governance version:** 1.2  
**Effective date:** 2026-07-25  
**Result:** APPROVED

## New universal decision

All install folders and install ZIPs must be flat. Subfolders and nested archive paths are prohibited.

## Build-blocking consequence

Any release containing a directory entry or member name with a path separator is FAIL, regardless of whether the code or automated tests pass.

## Documentation consequence

All required documents must remain in the install root. Naming prefixes replace directory organization.

## Prior releases

The WC-10 packages containing `tests/`, documentation, fixture, or reference subfolders are noncompliant and are not eligible for promotion.

## Authority

`RGBM-Universal-Release-and-Packaging-Rules.md` is the controlling universal release and packaging authority.
